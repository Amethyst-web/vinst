<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'version' => '1.5.6',
    'critical'=>'1.5.3',
    'vendor' => 'webasyst',
);
