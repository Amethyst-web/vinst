<?php

return array(
    'code' => 'AED',
    'sign' => 'AED',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'United Arab Emirates dirham',
    'name' => array(
        array('dirham', 'dirhams'),
    ),
    'frac_name' => array(
        'fils'
    )
);