<?php

return array(
    'code' => 'GEL',
    'sign' => 'lari',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Georgian lari',
    'name' => array(
        'lari',
    ),
    'frac_name' => array(
        'tetri',
    )
);