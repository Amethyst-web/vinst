<?php

return array(
    'code' => 'MMK',
    'sign' => 'K',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Burmese kyat',
    'name' => array(
        array('kyat', 'kyats'),
    ),
    'frac_name' => array(
        array('pya', 'pyas'),
    )
);