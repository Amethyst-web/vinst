<?php

return array(
    'code' => 'SGD',
    'sign' => '$',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Singapore dollar',
    'name' => array(
        array('dollar', 'dollars'),
        'S$',
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);