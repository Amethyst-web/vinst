<?php

return array(
    'code' => 'COP',
    'sign' => '$',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Colombian peso',
    'name' => array(
        array('peso', 'pesos'),
    ),
    'frac_name' => array(
        array('centavo', 'centavos'),
    )
);