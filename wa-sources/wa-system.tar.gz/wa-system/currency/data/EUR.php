<?php

return array(
    'code' => 'EUR',
    'sign' => '€',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Euro',
    'name' => array(
        'euro',
        'EU'
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);