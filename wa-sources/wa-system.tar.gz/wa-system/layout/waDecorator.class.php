<?php

class waDecorator
{
    public function display()
    {

    }
}